import styled from "styled-components";

export const StyledDiv = styled.div`
  height: 70vh;

`;

export const PlusStyle = styled.div`
  margin-top: 24rem;
  margin-right: 3rem;
  display: flex;
  justify-content: right;
`;
